package com.pet.ft.model;

import java.util.List;

import com.pet.ft.dto.MemberDto;

public interface PetBiz {

	public int totalMember();
	public List<MemberDto> memberList();
}
