package com.pet.ft.model;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.pet.ft.dto.BusinessDto;
import com.pet.ft.dto.MemberDto;

public class PetDaoImpl extends SqlMapConfig implements PetDao {

	private String namespace = "com.pet.ft.mapper.";

	@Override
	public int totalMember() {
		
		int res = 0;
		try (SqlSession session = getSqlSessionFactory().openSession(true)){
			res  = session.selectOne(namespace + "totalMember");
		}
	
		
		return res;
		
	}

	@Override
	public List<MemberDto> memberList() {
		
		SqlSession session = getSqlSessionFactory().openSession();
		List<MemberDto> list = session.selectList(namespace + "memberList");
		session.close();
		
		return list;
	}


	
	
}
