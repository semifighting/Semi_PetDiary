package com.pet.ft.model;

import java.util.List;

import com.pet.ft.dto.MemberDto;

public class PetBizImpl implements PetBiz {
	
	PetDao dao = new PetDaoImpl();

	@Override
	public int totalMember() {
		return dao.totalMember();
	}

	@Override
	public List<MemberDto> memberList() {
		return dao.memberList();
	}

}
