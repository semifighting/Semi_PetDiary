package com.pet.ft.model;

import java.util.List;

import com.pet.ft.dto.BusinessDto;
import com.pet.ft.dto.MemberDto;

public interface PetDao {

	public int totalMember();
	public List<MemberDto> memberList();
}
