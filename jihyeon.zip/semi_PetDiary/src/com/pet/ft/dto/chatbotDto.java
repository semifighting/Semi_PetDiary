package com.pet.ft.dto;

public class chatbotDto {
	
	private String uuid;

	public chatbotDto() {
	
	}

	public chatbotDto(String uuid) {
		this.uuid = uuid;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	
	
	
	
	

}
